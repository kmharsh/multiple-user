
async function getData() {

  var UserData = [];
  var childToAdd;

  for(let i=0; i< 4 ; i++){
   await fetch("https://randomuser.me/api").then( Response => {
      return Response.json()
    }).then( data => {
       UserData.push(data.results[0]);
    })
  }

  UserData.map( data => {

    childToAdd = `<div class="id-card">
    <div class="profile-row">
      <div class="dp">
        <div class="dp-arc-outer"></div>
        <div class="dp-arc-inner"></div>
        <img src=${data.picture.thumbnail}>
      </div>
      <div class="desc">
        <label class="lbl-cls">Email:- <p id="email">${data.email}</p></label>
        <label class="lbl-cls">Name :- <p id="name">${data.name.first}</p></label>
        <label class="lbl-cls"> City:- <p id="city">${data.location.city}</p></label>
        <label class="lbl-cls">Phone:- <p id="phone">${data.phone}</p></label>
        <label class="lbl-cls">DOB:- <p id="dob">${data.dob.date}</p></label>
      </div>
    </div>
  </div>`;

  $('.id-card-wrapper').append(childToAdd);

  });
}

getData();